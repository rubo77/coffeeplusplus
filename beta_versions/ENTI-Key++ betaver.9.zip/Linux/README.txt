INSTALL
----------
1.
copy the file to
/etc/X11/.xmodmap-ENTI-key++

2.
install the packet xmodmap with

sudo apt-get install xmodmap 

3.
then call xmodmap /etc/X11/.xmodmap-ENTI-key++
(you can enter this into your startupscript or call it every time you want to change to ENTI-key++)