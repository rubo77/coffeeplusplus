KP Typing Tutor 
For Win95/2000/XP   version 7.2

KP Typing Tutor is an easy-to-use and effective typing program that will help you to learn to type. A number of modules let you practice basic typing course, sentences, or longer text. An on-screen keyboard and L-R hands, highlights the key and finger to be used. 

KP Typing Tutor supports Dvorak keyboard layouts (Dvorak, Left Single-handed Dvorak and Right Single-handed Dvorak) with special typing courses. 

KP Typing Tutor Net Edition is a handy application for multi-user environments like schools, campus, language centers, labs, and companies which need centralized user managements and course managements. Free companion tools are available for you as a teacher to customize the tutor in order to meet your students' needs.

KP Typing Tutor  fully supports Qwerty keyboards and Dvorak keyboards. The whole design of the tutor is to encourage you to learn to type as soon as possible. The layouts and the courses are customizable for people of different backgrounds. 

Free companion tools are available for you as a teacher to customize the tutor for students. Layouts and course files in other alphabetic languages could be found at the International Section of KP Typing Tutor's homepage. 

Changing kpgame.ini
===================
Many settings of typing game could be modified through the window interfaces. However, to fine-tune the program, you might need to modify the INI file using a text editor.

[General]
NewWordSpeed=3500 ; initial speed factor of creating new word
NewWordSpeedBy=250 ; speed factor:=NewWordSpeed-difficulty * NewWordSpeedBy
DropSpeed=250 ; Dropdown speed factor
DropSpeedBy=20 ; speed factor:=DropSpeed - difficulty * DropSpeedBy
FunSpeed=1 ; 0: dropdown speeds of all words will be the same; 1: with different speeds

If you want creating new words at slower speed, just increase NewWordSpeed, say 7000. If you want drop down speed slower, increase DropSpeed, say 350.


For updated information about KP Typing Tutor series, please visit 
http://www.fonlow.com/kptypingtutor

Email: kpsupport@fonlow.com



