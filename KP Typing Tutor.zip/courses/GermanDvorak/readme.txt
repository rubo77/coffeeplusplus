The German course files including the on-screen keyboard were provided by Paul Bittner in Austria, Vienna.

The Windows keyboard driver can be downloaded
a) for Win9.x/ME at 
  http://paul.stefauli.at/dvorak/DvorakKeyboardSetup.exe  (Paul made an installation version - zip-version: DvorakKeyboard.zip in the same directory)
b) for WinNT/2000/XP at http://eurokeys.steveszone.com/


Important Notice:
The author of KP Typing Tutor Zijian Huang is NOT responsible for the content of this typing course. If you don't like the content of the courses, or you find some of the words in the practice contents are offending or slang, please just ignore or delete the content, and tell Zijian Huang. You might either modify the course or make your own course using the Typing Course Generator. From time to time, there are more and more practice contents in different languages available for download at KP Typing Tutor's official web site:
http://www.fonlow.com/zijianhuang/kp/

These typing course are provided by volunteers around the world to make good for their nations.

 